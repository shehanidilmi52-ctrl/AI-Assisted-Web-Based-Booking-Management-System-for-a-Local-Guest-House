<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php"); exit;
}
include '../config/db.php';
include '../includes/mailer.php';

$id = (int)($_GET['id'] ?? 0);

try {
    // Only allow cancellation of own bookings that are not already cancelled
    $stmt = $pdo->prepare("
        SELECT id, status, check_in, user_id FROM bookings WHERE id = ?
    ");
    $stmt->execute([$id]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$booking || $booking['user_id'] != $_SESSION['user_id']) {
        header("Location: ../pages/my-bookings.php?msg=error"); exit;
    }

    if ($booking['status'] === 'cancelled') {
        header("Location: ../pages/my-bookings.php?msg=error"); exit;
    }

    $pdo->prepare("UPDATE bookings SET status='cancelled' WHERE id=?")->execute([$id]);

    // Send cancellation email to guest
    try {
        $bk_stmt = $pdo->prepare("
            SELECT b.*, u.name AS guest_name, u.email AS guest_email,
                   r.room_number, r.room_type
            FROM bookings b
            JOIN users u ON b.user_id = u.id
            JOIN rooms  r ON b.room_id  = r.id
            WHERE b.id = ?
        ");
        $bk_stmt->execute([$id]);
        $bk = $bk_stmt->fetch(PDO::FETCH_ASSOC);
        if ($bk) email_booking_cancelled($bk);
    } catch (Exception $em) { /* email failure must not break cancellation */ }

    header("Location: ../pages/my-bookings.php?msg=cancelled"); exit;

} catch (Exception $e) {
    header("Location: ../pages/my-bookings.php?msg=error"); exit;
}
