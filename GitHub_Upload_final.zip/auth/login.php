<?php
session_start();
if (isset($_SESSION['user_id'])) { header("Location: ../pages/index.php"); exit; }
$page_title = 'Sign In';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include '../config/db.php';
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    if ($email && $pass) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            if ($user && password_verify($pass, $user['password'])) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name']    = $user['name'];
                $_SESSION['role']    = $user['role'];
                $dest = $_SESSION['redirect_after_login'] ?? null;
                unset($_SESSION['redirect_after_login']);
                header("Location: " . ($user['role']==='admin' ? '../admin/dashboard.php' : ($dest ?? '../pages/index.php')));
                exit;
            } else {
                $error = "Invalid email or password. Please try again.";
            }
        } catch(Exception $e) { $error = "Login failed. Please try again."; }
    } else { $error = "Please fill in all fields."; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign In — Rashmika Home Stay</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="auth-page">
  <div class="form-card" style="width:100%;">
    <div class="form-logo">
      <div class="form-logo-icon">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      </div>
      <div class="form-title">Welcome back</div>
      <div class="form-subtitle">Sign in to manage your bookings</div>
    </div>
    <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if(isset($_GET['registered'])): ?><div class="alert alert-success">Account created! Please sign in.</div><?php endif; ?>
    <?php if(isset($_GET['required'])): ?><div class="alert alert-info">Please sign in to continue.</div><?php endif; ?>
    <form method="POST">
      <div class="form-group">
        <label class="form-label" for="email">Email Address</label>
        <input type="email" id="email" name="email" class="form-control" value="<?= htmlspecialchars($_POST['email']??'') ?>" placeholder="you@example.com" required autofocus>
      </div>
      <div class="form-group">
        <label class="form-label" for="password">Password</label>
        <input type="password" id="password" name="password" class="form-control" placeholder="Your password" required>
      </div>
      <button type="submit" class="btn btn-primary w-full" style="margin-top:.5rem;">Sign In →</button>
    </form>
    <div class="form-divider"><span>New here?</span></div>
    <div class="text-center">
      <a href="register.php" class="form-link">Create a free account</a>
    </div>
    <div class="text-center mt-3">
      <a href="../pages/index.php" style="color:var(--grey-mid);font-size:.85rem;">← Back to Home</a>
    </div>
  </div>
</div>
</body></html>
