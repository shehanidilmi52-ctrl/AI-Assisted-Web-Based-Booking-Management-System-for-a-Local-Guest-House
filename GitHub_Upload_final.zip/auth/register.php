<?php
session_start();
if (isset($_SESSION['user_id'])) { header("Location: ../pages/index.php"); exit; }
$page_title = 'Create Account';
$error = ''; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include '../config/db.php';
    $name  = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    $conf  = $_POST['confirm'] ?? '';
    if (!$name || !$email || !$pass || !$conf) {
        $error = "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (strlen($pass) < 8) {
        $error = "Password must be at least 8 characters long.";
    } elseif ($pass !== $conf) {
        $error = "Passwords do not match.";
    } else {
        try {
            $check = $pdo->prepare("SELECT id FROM users WHERE email=?");
            $check->execute([$email]);
            if ($check->fetch()) {
                $error = "An account with this email already exists.";
            } else {
                $hash = password_hash($pass, PASSWORD_BCRYPT);
                $pdo->prepare("INSERT INTO users (name,email,password,role) VALUES (?,?,?,'customer')")
                    ->execute([$name, $email, $hash]);
                header("Location: login.php?registered=1"); exit;
            }
        } catch(Exception $e) { $error = "Registration failed. Please try again."; }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Account — Rashmika Home Stay</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="auth-page">
  <div class="form-card" style="width:100%;">
    <div class="form-logo">
      <div class="form-logo-icon">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      </div>
      <div class="form-title">Create your account</div>
      <div class="form-subtitle">Join us and enjoy easy, direct booking</div>
    </div>
    <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
      <div class="form-group">
        <label class="form-label" for="name">Full Name</label>
        <input type="text" id="name" name="name" class="form-control" value="<?= htmlspecialchars($_POST['name']??'') ?>" placeholder="Your full name" required autofocus>
      </div>
      <div class="form-group">
        <label class="form-label" for="email">Email Address</label>
        <input type="email" id="email" name="email" class="form-control" value="<?= htmlspecialchars($_POST['email']??'') ?>" placeholder="you@example.com" required>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label" for="password">Password</label>
          <input type="password" id="password" name="password" class="form-control" placeholder="Min. 8 characters" required minlength="8">
        </div>
        <div class="form-group">
          <label class="form-label" for="confirm">Confirm Password</label>
          <input type="password" id="confirm" name="confirm" class="form-control" placeholder="Repeat password" required>
        </div>
      </div>
      <div class="input-hint mb-2">By creating an account you agree to our terms and privacy policy.</div>
      <button type="submit" class="btn btn-primary w-full">Create Account →</button>
    </form>
    <div class="form-divider"><span>Already have an account?</span></div>
    <div class="text-center">
      <a href="login.php" class="form-link">Sign in instead</a>
    </div>
    <div class="text-center mt-3">
      <a href="../pages/index.php" style="color:var(--grey-mid);font-size:.85rem;">← Back to Home</a>
    </div>
  </div>
</div>
</body></html>
