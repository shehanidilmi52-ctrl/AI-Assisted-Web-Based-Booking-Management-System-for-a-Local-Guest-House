<?php
/**
 * DATABASE CONFIGURATION — EXAMPLE FILE
 * ======================================
 * Copy this file to  config/db.php  and fill in your real credentials.
 * NEVER commit  config/db.php  to version control.
 *
 * Local XAMPP / WAMP defaults are shown below.
 * For cPanel hosting, change DB_HOST to 'localhost', DB_PORT to '3306',
 * and set DB_USER / DB_PASS to your hosting database credentials.
 */

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');           // XAMPP default; change to 3307 if needed
define('DB_NAME', 'booking_system'); // Create this database first (see README)
define('DB_USER', 'root');           // Replace with your MySQL username
define('DB_PASS', '');               // Replace with your MySQL password

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die('<div style="font-family:sans-serif;padding:2rem;color:#B91C1C;background:#FEE2E2;border-radius:8px;margin:2rem auto;max-width:500px;">
         <strong>Database connection failed.</strong><br>'
         . $e->getMessage()
         . '<br><br>Check your credentials in <code>config/db.php</code>.</div>');
}
