<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = '../pages/booking.php' . ($_SERVER['QUERY_STRING']?"?".$_SERVER['QUERY_STRING']:'');
    header("Location: ../auth/login.php?required=1"); exit;
}
$page_title = 'Book a Room';
include '../includes/header.php';
include '../config/db.php';
include '../includes/mailer.php';

$room_id   = (int)($_GET['room_id'] ?? $_POST['room_id'] ?? 0);
$check_in  = $_GET['check_in']  ?? $_POST['check_in']  ?? '';
$check_out = $_GET['check_out'] ?? $_POST['check_out'] ?? '';
$error = ''; $success_id = null;

// Fetch room
$room = null;
if ($room_id) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM rooms WHERE id=? AND is_available=1");
        $stmt->execute([$room_id]);
        $room = $stmt->fetch();
    } catch(Exception $e) {}
}

// Fetch all available rooms for selector
try {
    $all_rooms = $pdo->query("SELECT * FROM rooms WHERE is_available=1 ORDER BY price_per_night")->fetchAll();
} catch(Exception $e) { $all_rooms = []; }

// Handle form submit
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $room_id   = (int)($_POST['room_id']??0);
    $check_in  = $_POST['check_in']??'';
    $check_out = $_POST['check_out']??'';
    $requests  = trim($_POST['special_requests']??'');

    if (!$room_id||!$check_in||!$check_out) {
        $error = "Please fill in all required fields.";
    } elseif ($check_in >= $check_out) {
        $error = "Check-out date must be after check-in date.";
    } elseif ($check_in < date('Y-m-d')) {
        $error = "Check-in date cannot be in the past.";
    } else {
        try {
            // Availability check
            $avail = $pdo->prepare("
                SELECT COUNT(*) FROM bookings
                WHERE room_id=? AND status IN ('pending','confirmed')
                AND check_in < ? AND check_out > ?
            ");
            $avail->execute([$room_id, $check_out, $check_in]);
            if ($avail->fetchColumn() > 0) {
                $error = "Sorry, this room is not available for the selected dates. Please choose different dates.";
            } else {
                $room_data = $pdo->prepare("SELECT * FROM rooms WHERE id=?")->execute([$room_id]) ? null : null;
                $stmt2 = $pdo->prepare("SELECT price_per_night FROM rooms WHERE id=?");
                $stmt2->execute([$room_id]);
                $price = $stmt2->fetchColumn();
                $nights = (strtotime($check_out)-strtotime($check_in))/86400;
                $total  = $nights * $price;
                // Try inserting with special_requests column; if it doesn't exist, insert without it
                try {
                    $ins = $pdo->prepare("INSERT INTO bookings (user_id,room_id,check_in,check_out,total_price,status,special_requests) VALUES (?,?,?,?,?,'pending',?)");
                    $ins->execute([$_SESSION['user_id'],$room_id,$check_in,$check_out,$total,$requests]);
                } catch(Exception $e2) {
                    $ins = $pdo->prepare("INSERT INTO bookings (user_id,room_id,check_in,check_out,total_price,status) VALUES (?,?,?,?,?,'pending')");
                    $ins->execute([$_SESSION['user_id'],$room_id,$check_in,$check_out,$total]);
                }
                $success_id = $pdo->lastInsertId();

                // Send booking received email to guest
                try {
                    $bk_stmt = $pdo->prepare("
                        SELECT b.*, u.name AS guest_name, u.email AS guest_email,
                               r.room_number, r.room_type
                        FROM bookings b
                        JOIN users u ON b.user_id = u.id
                        JOIN rooms  r ON b.room_id  = r.id
                        WHERE b.id = ?
                    ");
                    $bk_stmt->execute([$success_id]);
                    $bk = $bk_stmt->fetch(PDO::FETCH_ASSOC);
                    if ($bk) email_booking_pending($bk);
                } catch (Exception $em) { /* email failure must not break booking */ }
            }
        } catch(Exception $e) { $error = "Booking failed: " . $e->getMessage(); }
    }
}

$nights_preview = ($check_in&&$check_out&&$check_in<$check_out) ? (strtotime($check_out)-strtotime($check_in))/86400 : 0;
?>

<div class="page-header">
  <div class="container">
    <h1>Book Your Room</h1>
    <p>Select your room and dates. We'll confirm your reservation instantly.</p>
  </div>
</div>

<section class="section">
  <div class="container">

    <?php if($success_id): ?>
      <div style="max-width:580px;margin:0 auto;text-align:center;padding:3rem 2rem;">
        <div style="margin-bottom:1.25rem;">
          <svg style="width:64px;height:64px;color:var(--teal-mid)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
        </div>
        <h2 style="color:var(--green-ok);margin-bottom:.75rem;">Booking Confirmed!</h2>
        <p style="margin-bottom:2rem;">Your booking <strong>#<?= str_pad($success_id,4,'0',STR_PAD_LEFT) ?></strong> has been received and is <strong>pending confirmation</strong>. You'll be notified once the host confirms.</p>
        <div style="display:flex;gap:1rem;justify-content:center;">
          <a href="my-bookings.php" class="btn btn-teal btn-lg">View My Bookings</a>
          <a href="rooms.php" class="btn btn-ghost btn-lg">Book Another</a>
        </div>
      </div>
    <?php else: ?>
      <?php if($error): ?><div class="alert alert-danger" style="max-width:860px;margin:0 auto 1.5rem;"><?= htmlspecialchars($error) ?></div><?php endif; ?>

      <div class="booking-wrapper">
        <!-- Main Form -->
        <div class="form-card form-card-wide" style="max-width:100%;">
          <div style="margin-bottom:1.75rem;">
            <h3 style="color:var(--teal-deep);margin-bottom:.25rem;">Reservation Details</h3>
            <p style="font-size:.88rem;">All fields marked * are required.</p>
          </div>
          <form method="POST" id="bookingForm">
            <div class="form-group">
              <label class="form-label">Select Room *</label>
              <select name="room_id" id="roomSelect" class="form-control" required>
                <option value="">— Choose a room —</option>
                <?php foreach($all_rooms as $r): ?>
                  <option value="<?= $r['id'] ?>" data-price="<?= $r['price_per_night'] ?>"
                    <?= $room_id==$r['id']?'selected':'' ?>>
                    Room <?= htmlspecialchars($r['room_number']) ?> — <?= htmlspecialchars($r['room_type']) ?> (Rs.<?= number_format($r['price_per_night']) ?>/night)
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Check-in Date *</label>
                <input type="date" name="check_in" id="checkIn" class="form-control"
                       value="<?= htmlspecialchars($check_in) ?>" min="<?= date('Y-m-d') ?>" required>
              </div>
              <div class="form-group">
                <label class="form-label">Check-out Date *</label>
                <input type="date" name="check_out" id="checkOut" class="form-control"
                       value="<?= htmlspecialchars($check_out) ?>" min="<?= date('Y-m-d',strtotime('+1 day')) ?>" required>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Special Requests (optional)</label>
              <textarea name="special_requests" class="form-control" rows="3"
                        placeholder="e.g. early check-in, ground floor room, extra pillows…"><?= htmlspecialchars($_POST['special_requests']??'') ?></textarea>
            </div>
            <div style="background:var(--teal-xlight);border-radius:var(--r-md);padding:1rem 1.25rem;margin-bottom:1.5rem;font-size:.88rem;color:var(--teal-mid);">
              ✓ Free cancellation up to 24 hours before check-in &nbsp;|&nbsp; ✓ No credit card required &nbsp;|&nbsp; ✓ Instant confirmation
            </div>
            <button type="submit" class="btn btn-primary btn-lg w-full">Confirm Booking →</button>
          </form>
        </div>

        <!-- Summary -->
        <div class="booking-summary">
          <div class="booking-summary-header">
            <h3>Booking Summary</h3>
            <div style="font-size:.82rem;color:rgba(255,255,255,.65);">Estimates update automatically</div>
          </div>
          <div class="booking-summary-body">
            <div class="summary-row"><span class="summary-label">Room</span><span class="summary-value" id="summRoom">—</span></div>
            <div class="summary-row"><span class="summary-label">Check-in</span><span class="summary-value" id="summCheckIn">—</span></div>
            <div class="summary-row"><span class="summary-label">Check-out</span><span class="summary-value" id="summCheckOut">—</span></div>
            <div class="summary-row"><span class="summary-label">Nights</span><span class="summary-value" id="summNights">—</span></div>
            <div class="summary-row"><span class="summary-label">Rate / night</span><span class="summary-value" id="summRate">—</span></div>
          </div>
          <div class="summary-total">
            <div style="font-size:.8rem;color:var(--teal-mid);margin-bottom:.25rem;">Estimated Total</div>
            <div class="total-amount" id="summTotal">Rs. —</div>
          </div>
        </div>
      </div>
    <?php endif; ?>

  </div>
</section>

<script>
function fmt(n){ return 'Rs. ' + n.toLocaleString('en-LK'); }
function fmtDate(s){ if(!s)return'—'; const d=new Date(s+'T00:00:00'); return d.toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}); }
function update(){
  const sel=document.getElementById('roomSelect');
  const ci =document.getElementById('checkIn').value;
  const co =document.getElementById('checkOut').value;
  const price=sel.selectedIndex>0?parseFloat(sel.options[sel.selectedIndex].dataset.price):0;
  const rName=sel.selectedIndex>0?sel.options[sel.selectedIndex].text.split('—')[0].trim():'—';
  const nights=(ci&&co&&ci<co)?(new Date(co)-new Date(ci))/86400000:0;
  document.getElementById('summRoom').textContent     = rName;
  document.getElementById('summCheckIn').textContent  = fmtDate(ci);
  document.getElementById('summCheckOut').textContent = fmtDate(co);
  document.getElementById('summNights').textContent   = nights>0?nights+' night'+(nights>1?'s':''):'—';
  document.getElementById('summRate').textContent     = price>0?fmt(price):'—';
  document.getElementById('summTotal').textContent    = (price>0&&nights>0)?fmt(price*nights):'Rs. —';
  if(co){ document.getElementById('checkOut').min=new Date(new Date(ci||new Date()).getTime()+86400000).toISOString().slice(0,10); }
}
document.getElementById('roomSelect').addEventListener('change',update);
document.getElementById('checkIn').addEventListener('change',update);
document.getElementById('checkOut').addEventListener('change',update);
update();
</script>

<?php include '../includes/footer.php'; ?>
