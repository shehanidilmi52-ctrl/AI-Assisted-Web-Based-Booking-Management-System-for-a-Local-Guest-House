<?php
session_start();
$page_title = 'Our Rooms';
include '../includes/header.php';
include '../config/db.php';

$type_filter = $_GET['type'] ?? '';
$check_in    = $_GET['check_in'] ?? '';
$check_out   = $_GET['check_out'] ?? '';

try {
    $sql = "SELECT * FROM rooms WHERE 1=1";
    $params = [];
    if ($type_filter) { $sql .= " AND room_type = ?"; $params[] = $type_filter; }
    if ($check_in && $check_out) {
        $sql .= " AND id NOT IN (
            SELECT room_id FROM bookings
            WHERE status IN ('pending','confirmed')
            AND check_in  < ?
            AND check_out > ?
        )";
        $params[] = $check_out; $params[] = $check_in;
    }
    $sql .= " ORDER BY price_per_night ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rooms = $stmt->fetchAll();
    $types = $pdo->query("SELECT DISTINCT room_type FROM rooms ORDER BY room_type")->fetchAll(PDO::FETCH_COLUMN);
} catch(Exception $e) { $rooms=[]; $types=[]; }

// Real photos — same paths stored in DB
$default_imgs = [
    'Double Room with Shared Bathroom' => '../assets/images/room-101.jpg',
    'Double Room'                      => '../assets/images/room-102.jpg',
    'Family Room'                      => '../assets/images/room-103.jpg',
    'Deluxe Room'                      => '../assets/images/room-104.jpg',
];

// Amenity pills — no emojis
$amenity_map = [
    'Double Room with Shared Bathroom' => ['Wi-Fi','AC','Shower','Shared Bath'],
    'Double Room'                      => ['Wi-Fi','AC','Shower','Mirror'],
    'Family Room'                      => ['Wi-Fi','AC','Bathtub','Extra Beds','TV'],
    'Deluxe Room'                      => ['Wi-Fi','AC','Bathtub','Garden View','Tea Set','TV'],
];
?>

<div class="page-header">
  <div class="container">
    <h1>Our Rooms</h1>
    <p>Comfortable, clean, and thoughtfully furnished. All rooms include free Wi-Fi and air conditioning.</p>
  </div>
</div>

<section class="section">
  <div class="container">

    <!-- Filter Bar -->
    <form method="GET" style="background:var(--white);border:1px solid var(--grey-light);border-radius:var(--r-lg);padding:1.5rem;margin-bottom:2.5rem;box-shadow:var(--shadow-sm);">
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr auto;gap:1rem;align-items:end;">
        <div class="form-group" style="margin:0;">
          <label class="form-label">Room Type</label>
          <select name="type" class="form-control">
            <option value="">All Types</option>
            <?php foreach($types as $t): ?>
              <option value="<?= htmlspecialchars($t) ?>" <?= $type_filter===$t?'selected':'' ?>><?= htmlspecialchars($t) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group" style="margin:0;">
          <label class="form-label">Check-in Date</label>
          <input type="date" name="check_in" class="form-control" value="<?= htmlspecialchars($check_in) ?>" min="<?= date('Y-m-d') ?>">
        </div>
        <div class="form-group" style="margin:0;">
          <label class="form-label">Check-out Date</label>
          <input type="date" name="check_out" class="form-control" value="<?= htmlspecialchars($check_out) ?>" min="<?= date('Y-m-d',strtotime('+1 day')) ?>">
        </div>
        <div style="display:flex;gap:.5rem;">
          <button type="submit" class="btn btn-primary">Search</button>
          <?php if($type_filter||$check_in): ?>
            <a href="rooms.php" class="btn btn-ghost">Clear</a>
          <?php endif; ?>
        </div>
      </div>
    </form>

    <?php if(empty($rooms)): ?>
      <div class="empty-state">
        <svg style="width:56px;height:56px;color:var(--teal-mid);margin:0 auto 1rem;display:block;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
        <h3>No rooms found</h3>
        <p>Try adjusting your dates or room type filter.</p>
        <a href="rooms.php" class="btn btn-teal mt-3">View All Rooms</a>
      </div>
    <?php else: ?>
      <div class="rooms-grid">
      <?php foreach($rooms as $room):
        $pills = $amenity_map[$room['room_type']] ?? ['Wi-Fi','AC','Shower'];
        // Fix: use is_available column (not status)
        $avail = ($room['is_available'] ?? 0) == 1;
        // Use DB image if set, else fall back to local default
        $img   = !empty($room['image']) ? htmlspecialchars($room['image']) : ($default_imgs[$room['room_type']] ?? '../assets/images/room-102.jpg');
      ?>
        <div class="room-card">
          <div class="room-img">
            <img src="<?= $img ?>" alt="<?= htmlspecialchars($room['room_type']) ?>" loading="lazy">
            <span class="room-badge <?= $avail?'':'unavailable' ?>"><?= $avail?'Available':'Booked' ?></span>
          </div>
          <div class="room-body">
            <div class="room-type"><?= htmlspecialchars($room['room_type']) ?></div>
            <div class="room-name">Room <?= htmlspecialchars($room['room_number']) ?></div>
            <div class="room-desc"><?= htmlspecialchars($room['description'] ?? 'Well-maintained room with all essential amenities for a comfortable stay.') ?></div>
            <div class="room-amenities">
              <?php foreach($pills as $p): ?><span class="amenity-pill"><?= $p ?></span><?php endforeach; ?>
              <span class="amenity-pill"><?= $room['capacity'] ?> Guests</span>
            </div>
            <div class="room-footer">
              <div class="room-price">
                <span class="amount">Rs.<?= number_format($room['price_per_night']) ?></span>
                <span class="unit">per night</span>
              </div>
              <?php if($avail): ?>
                <a href="booking.php?room_id=<?= $room['id'] ?><?= $check_in?"&check_in=$check_in":''; ?><?= $check_out?"&check_out=$check_out":''; ?>" class="btn btn-primary btn-sm">Book Now</a>
              <?php else: ?>
                <span class="badge cancelled">Unavailable</span>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </div>
</section>

<?php include '../includes/footer.php'; ?>
