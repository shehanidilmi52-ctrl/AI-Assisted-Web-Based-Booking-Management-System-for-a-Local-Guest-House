<?php
session_start();
$page_title = 'Home';
include '../includes/header.php';
include '../config/db.php';
try {
    $available_count = $pdo->query("SELECT COUNT(*) FROM rooms WHERE is_available=1")->fetchColumn();
    $total_rooms     = $pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
    $min_price       = $pdo->query("SELECT MIN(price_per_night) FROM rooms")->fetchColumn();
    $total_guests    = $pdo->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn();
} catch(Exception $e) { $available_count=4;$total_rooms=4;$min_price=2500;$total_guests=120; }
?>

<!-- HERO -->
<section class="hero">
  <div class="hero-content">
    <div class="hero-eyebrow">Nallathanniya Road, Laxapana Estate, Maskeliya — Gateway to Adam's Peak</div>
    <h1>Your home at <em>Adam's Peak</em></h1>
    <p class="hero-desc">Comfortable, affordable rooms with warm Sri Lankan hospitality at the foot of Sri Pada. Book directly with Rashmika Homestay — no commission fees, no middlemen, instant confirmation.</p>
    <div class="hero-actions">
      <a href="rooms.php" class="btn btn-primary btn-lg">View Rooms</a>
      <a href="booking.php" class="btn btn-outline btn-lg">Book Now</a>
    </div>
    <div class="hero-stats">
      <div>
        <span class="hero-stat-num"><?= $available_count ?>+</span>
        <span class="hero-stat-lbl">Rooms Available</span>
      </div>
      <div>
        <span class="hero-stat-num">Rs.<?= number_format((int)$min_price) ?></span>
        <span class="hero-stat-lbl">From per night</span>
      </div>
      <div>
        <span class="hero-stat-num">24/7</span>
        <span class="hero-stat-lbl">AI Assistant</span>
      </div>
    </div>
  </div>
</section>

<!-- FEATURE STRIP -->
<div class="feature-strip">
  <div class="container">
    <div class="feature-item"><div class="fi-icon fi-check"></div><div class="fi-text"><strong>Free Cancellation</strong><span>Up to 24 hours before</span></div></div>
    <div class="feature-item"><div class="fi-icon fi-clock"></div><div class="fi-text"><strong>Check-in 2 PM</strong><span>Check-out by 11 AM</span></div></div>
    <div class="feature-item"><div class="fi-icon fi-wifi"></div><div class="fi-text"><strong>Free Wi-Fi</strong><span>All rooms included</span></div></div>
    <div class="feature-item"><div class="fi-icon fi-bot"></div><div class="fi-text"><strong>AI Chatbot</strong><span>24/7 instant answers</span></div></div>
    <div class="feature-item"><div class="fi-icon fi-peak"></div><div class="fi-text"><strong>Adam's Peak</strong><span>5 min to trailhead</span></div></div>
  </div>
</div>

<!-- ROOMS PREVIEW -->
<section class="section">
  <div class="container">
    <div class="section-header">
      <div class="section-eyebrow">Our Rooms</div>
      <h2>Choose your perfect stay</h2>
      <p>All rooms are carefully maintained with modern amenities to make you feel right at home.</p>
    </div>
    <?php
    try {
        $rooms = $pdo->query("SELECT * FROM rooms ORDER BY price_per_night ASC LIMIT 4")->fetchAll();
    } catch(Exception $e) { $rooms = []; }
    $badges = [
      'Double Room with Shared Bathroom'=>['Wi-Fi','Shower','AC'],
      'Double Room'=>['Wi-Fi','Shower','AC','En-suite'],
      'Family Room'=>['Wi-Fi','AC','Extra Beds','4 Guests'],
      'Deluxe Room'=>['Wi-Fi','Bathtub','AC','Premium'],
    ];
    // Default local images per room type if DB image is empty
    $default_imgs = [
      'Double Room with Shared Bathroom'=>'../assets/images/room-101.jpg',
      'Double Room'=>'../assets/images/room-102.jpg',
      'Family Room'=>'../assets/images/room-103.jpg',
      'Deluxe Room'=>'../assets/images/room-104.jpg',
    ];
    ?>
    <div class="rooms-grid">
    <?php foreach($rooms as $room):
      $pills = $badges[$room['room_type']] ?? ['Wi-Fi','AC','Shower'];
      $avail = ($room['is_available'] ?? 0) == 1;
      // DB stores '../assets/images/room-X.jpg' — correct relative path from pages/
      $img   = !empty($room['image']) ? htmlspecialchars($room['image']) : ($default_imgs[$room['room_type']] ?? '../assets/images/room-102.jpg');
    ?>
      <div class="room-card">
        <div class="room-img">
          <img src="<?= $img ?>" alt="<?= htmlspecialchars($room['room_type']) ?>" loading="lazy">
          <span class="room-badge <?= $avail?'':'unavailable' ?>"><?= $avail?'Available':'Booked' ?></span>
        </div>
        <div class="room-body">
          <div class="room-type"><?= htmlspecialchars($room['room_type']) ?></div>
          <div class="room-name">Room <?= htmlspecialchars($room['room_number']) ?></div>
          <div class="room-desc"><?= htmlspecialchars($room['description'] ?? 'Comfortable and well-appointed room with all essential amenities.') ?></div>
          <div class="room-amenities">
            <?php foreach($pills as $p): ?><span class="amenity-pill"><?= $p ?></span><?php endforeach; ?>
            <span class="amenity-pill"><?= $room['capacity'] ?> Guests</span>
          </div>
          <div class="room-footer">
            <div class="room-price">
              <span class="amount">Rs.<?= number_format($room['price_per_night']) ?></span>
              <span class="unit">per night</span>
            </div>
            <?php if($avail): ?>
              <a href="booking.php?room_id=<?= $room['id'] ?>" class="btn btn-primary btn-sm">Book Now</a>
            <?php else: ?>
              <span class="badge cancelled">Unavailable</span>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    </div>
    <div class="text-center mt-4">
      <a href="rooms.php" class="btn btn-teal btn-lg">View All Rooms</a>
    </div>
  </div>
</section>

<!-- AMENITIES -->
<section class="section" style="background:var(--white);">
  <div class="container">
    <div class="section-header">
      <div class="section-eyebrow">Why Choose Us</div>
      <h2>Everything you need</h2>
      <p>Rashmika Home Stay is designed for your comfort, with amenities that make every stay special.</p>
    </div>
    <div class="amenities-grid">
      <div class="amenity-card">
        <svg class="amenity-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 20l7-14 4 8 2-4 5 10H3z"/></svg>
        <h4>Adam's Peak Trail</h4><p>Just minutes from the Nallathanniya trailhead to Sri Pada (Adam's Peak).</p>
      </div>
      <div class="amenity-card">
        <svg class="amenity-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M5 12.55a11 11 0 0114.08 0M1.42 9a16 16 0 0121.16 0M8.53 16.11a6 6 0 016.95 0M12 20h.01"/></svg>
        <h4>Free Wi-Fi</h4><p>High-speed internet throughout the property, perfect for staying connected.</p>
      </div>
      <div class="amenity-card">
        <svg class="amenity-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="5"/><path d="M12 2v2M12 20v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M2 12h2M20 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
        <h4>Warm Rooms</h4><p>Cozy heated rooms to keep you comfortable in the cool mountain climate.</p>
      </div>
      <div class="amenity-card">
        <svg class="amenity-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8h1a4 4 0 010 8h-1M2 8h16v9a4 4 0 01-4 4H6a4 4 0 01-4-4V8zM6 1v3M10 1v3M14 1v3"/></svg>
        <h4>Sri Lankan Breakfast</h4><p>Enjoy authentic Sri Lankan breakfast made fresh each morning before your trek.</p>
      </div>
      <div class="amenity-card">
        <svg class="amenity-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13" rx="2"/><path d="M16 8h4l3 3v5h-7V8zM5.5 21a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM18.5 21a2.5 2.5 0 100-5 2.5 2.5 0 000 5z"/></svg>
        <h4>Free Parking</h4><p>Secure on-site parking available at no extra charge.</p>
      </div>
      <div class="amenity-card">
        <svg class="amenity-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M12 2a2 2 0 012 2v7H10V4a2 2 0 012-2z"/><circle cx="8" cy="16" r="1" fill="currentColor"/><circle cx="16" cy="16" r="1" fill="currentColor"/></svg>
        <h4>AI Chatbot</h4><p>Get instant answers about trail info, weather and rooms 24/7.</p>
      </div>
      <div class="amenity-card">
        <svg class="amenity-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
        <h4>Secure Booking</h4><p>Your data and booking information are protected with modern encryption.</p>
      </div>
      <div class="amenity-card">
        <svg class="amenity-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v2m0 8v2m-3-7h4.5a1.5 1.5 0 010 3H9m0 0h1.5a1.5 1.5 0 010 3H9"/></svg>
        <h4>Best Price</h4><p>Book direct and get the best rate — no booking platform commissions.</p>
      </div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="testimonials-section">
  <div class="container">
    <div class="section-header">
      <div class="section-eyebrow">Guest Reviews</div>
      <h2>What our guests say</h2>
    </div>
    <div class="testimonials-grid">
      <div class="testimonial-card"><div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><p class="testimonial-text">"The warmest hospitality I've experienced in Sri Lanka. The room was spotless and Adam's Peak was an unforgettable experience. We'll definitely be back!"</p><div class="testimonial-author"><div class="author-avatar author-de">DE</div><div><div class="author-name">Anna M.</div><div class="author-from">Germany</div></div></div></div>
      <div class="testimonial-card"><div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><p class="testimonial-text">"Booked directly through the website — so easy! The AI chatbot answered all my questions instantly. Great value for money in Maskeliya."</p><div class="testimonial-author"><div class="author-avatar author-uk">UK</div><div><div class="author-name">James T.</div><div class="author-from">United Kingdom</div></div></div></div>
      <div class="testimonial-card"><div class="stars">&#9733;&#9733;&#9733;&#9733;&#9734;</div><p class="testimonial-text">"Perfect base for climbing Adam's Peak. Family room was spacious and comfortable. The owner was incredibly helpful with trail tips."</p><div class="testimonial-author"><div class="author-avatar author-au">AU</div><div><div class="author-name">Sarah K.</div><div class="author-from">Australia</div></div></div></div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-section">
  <div class="container">
    <div class="cta-banner">
      <h2>Ready for your Adam's Peak adventure?</h2>
      <p>Book directly with us for the best rates and instant confirmation. No hidden fees.</p>
      <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;position:relative;">
        <a href="rooms.php" class="btn btn-white btn-lg">View Rooms</a>
        <?php if(!isset($_SESSION['user_id'])): ?>
          <a href="../auth/register.php" class="btn btn-outline btn-lg">Create Account</a>
        <?php else: ?>
          <a href="booking.php" class="btn btn-outline btn-lg">Book a Room</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<script>
document.querySelector('.nav-toggle')?.addEventListener('click',function(){
  document.querySelector('.navbar-nav').classList.toggle('open');
});
</script>

<?php include '../includes/footer.php'; ?>
