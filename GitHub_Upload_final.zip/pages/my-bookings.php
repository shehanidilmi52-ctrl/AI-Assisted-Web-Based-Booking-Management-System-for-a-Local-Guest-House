<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = '../pages/my-bookings.php';
    header("Location: ../auth/login.php?required=1"); exit;
}
$page_title = 'My Bookings';
include '../includes/header.php';
include '../config/db.php';

try {
    $stmt = $pdo->prepare("
        SELECT b.*, r.room_number, r.room_type, r.price_per_night
        FROM bookings b JOIN rooms r ON b.room_id = r.id
        WHERE b.user_id = ?
        ORDER BY b.created_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $bookings = $stmt->fetchAll();
} catch(Exception $e) { $bookings = []; }

$msg = $_GET['msg'] ?? '';
?>

<div class="page-header">
  <div class="container">
    <h1>My Bookings</h1>
    <p>View and manage all your reservations at Rashmika Home Stay.</p>
  </div>
</div>

<section class="section">
  <div class="container" style="max-width:860px;">

    <?php if($msg==='cancelled'): ?><div class="alert alert-success">Your booking has been cancelled successfully.</div><?php endif; ?>
    <?php if($msg==='error'):     ?><div class="alert alert-danger">Something went wrong. Please try again.</div><?php endif; ?>

    <?php if(empty($bookings)): ?>
      <div class="empty-state">
        <div class="empty-icon">
          <svg style="width:56px;height:56px;color:var(--teal-mid)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
        </div>
        <h3>No bookings yet</h3>
        <p>You haven't made any reservations yet. Browse our rooms and book your perfect stay!</p>
        <a href="rooms.php" class="btn btn-primary mt-3">Browse Rooms</a>
      </div>
    <?php else: ?>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;">
        <h3 style="color:var(--teal-deep);"><?= count($bookings) ?> Booking<?= count($bookings)>1?'s':'' ?></h3>
        <a href="rooms.php" class="btn btn-primary btn-sm">+ New Booking</a>
      </div>
      <div class="bookings-list">
      <?php foreach($bookings as $b):
        $nights = max(1, (strtotime($b['check_out'])-strtotime($b['check_in']))/86400);
        $icon   = '';
      ?>
        <div class="booking-item">
          <div class="booking-item-header">
            <div>
              <div class="booking-ref">Booking #<?= str_pad($b['id'],4,'0',STR_PAD_LEFT) ?></div>
              <div class="booking-date-booked">Booked on <?= date('d M Y', strtotime($b['created_at'])) ?></div>
            </div>
            <span class="badge <?= $b['status'] ?>"><?= ucfirst($b['status']) ?></span>
          </div>
          <div class="booking-item-body">
            <div>
              <div class="booking-room-name"><?= $icon ?> Room <?= htmlspecialchars($b['room_number']) ?> — <?= htmlspecialchars($b['room_type']) ?></div>
              <div class="booking-dates">
                <span><?= date('d M Y', strtotime($b['check_in'])) ?></span>
                <span>→</span>
                <span><?= date('d M Y', strtotime($b['check_out'])) ?></span>
                <span style="color:var(--teal-mid);font-weight:600;">(<?= $nights ?> night<?= $nights>1?'s':'' ?>)</span>
              </div>
              <div style="margin-top:.5rem;font-size:.88rem;">
                <strong style="color:var(--coral);font-size:1.1rem;">Rs.<?= number_format($b['total_price']) ?></strong>
                <span style="color:var(--grey-mid);"> total</span>
              </div>
            </div>
            <div class="booking-actions">
              <?php if($b['status']==='pending'): ?>
                <a href="../api/cancel-booking.php?id=<?= $b['id'] ?>"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Are you sure you want to cancel this booking?')">
                  Cancel
                </a>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </div>
</section>

<?php include '../includes/footer.php'; ?>
