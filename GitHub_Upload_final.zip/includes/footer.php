<?php
$is_admin = strpos($_SERVER['PHP_SELF'], '/admin/') !== false;
// Reliable base path: always relative to htdocs/rashmika/
$script = str_replace('\\','/',$_SERVER['PHP_SELF']);
preg_match('#/rashmika/(.*/)#i', $script, $m);
$depth = $m[1] ? substr_count(rtrim($m[1],'/'), '/') + 1 : 0;
$base  = str_repeat('../', $depth);
?>
<?php if (!$is_admin): ?>
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand-name">Rashmika Home Stay</div>
        <p>A peaceful retreat near Nallathanniya, Maskeliya — the gateway to Adam's Peak. Warm Sri Lankan hospitality, comfortable rooms, and easy online booking.</p>
      </div>
      <div class="footer-col">
        <h4>Quick Links</h4>
        <a href="<?= $base ?>pages/index.php">Home</a>
        <a href="<?= $base ?>pages/rooms.php">Our Rooms</a>
        <a href="<?= $base ?>pages/booking.php">Book a Room</a>
        <?php if(isset($_SESSION['user_id'])): ?>
          <a href="<?= $base ?>pages/my-bookings.php">My Bookings</a>
        <?php else: ?>
          <a href="<?= $base ?>auth/register.php">Create Account</a>
          <a href="<?= $base ?>auth/login.php">Sign In</a>
        <?php endif; ?>
      </div>
      <div class="footer-col">
        <h4>Contact Us</h4>
        <a href="https://maps.app.goo.gl/7GKHwRKTrVBJ2dYx7" target="_blank">Nallathanniya Road, Laxapana Estate, Maskeliya, Nuwara Eliya</a>
        <a href="tel:+94777123456">+94 77 712 3456</a>
        <a href="mailto:info@rashmikahomestay.lk">info@rashmikahomestay.lk</a>
        <a href="#">Check-in: 2:00 PM &nbsp;|&nbsp; Check-out: 11:00 AM</a>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?= date('Y') ?> Rashmika Home Stay. All rights reserved.</span>
      <span style="color:rgba(255,255,255,.4);">Powered by AI-Assisted Booking System</span>
    </div>
  </div>
</footer>
<?php endif; ?>

<!-- AI Chatbot Widget -->
<?php if (!$is_admin): ?>
<div class="chatbot-fab" id="chatbotFab">
  <div class="chatbot-window" id="chatbotWindow">
    <div class="chatbot-header">
      <div class="chatbot-avatar"></div>
      <div class="chatbot-header-info">
        <div class="chatbot-name">Rashmika AI Assistant</div>
        <div class="chatbot-status">Online now</div>
      </div>
      <button class="chatbot-close" id="chatbotClose" aria-label="Close">&times;</button>
    </div>
    <div class="chatbot-messages" id="chatbotMessages">
      <div class="chat-msg bot">Hello! Welcome to Rashmika Home Stay. How can I help you today?</div>
      <div class="chat-msg bot">Ask me about rooms, pricing, check-in times, or local attractions!</div>
    </div>
    <div class="chatbot-input-row">
      <input class="chatbot-input" id="chatbotInput" type="text" placeholder="Type your question…" autocomplete="off">
      <button class="chatbot-send" id="chatbotSend" aria-label="Send">&#10148;</button>
    </div>
  </div>
  <button class="chatbot-toggle" id="chatbotToggle" aria-label="Open chat">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
    <span class="chatbot-badge" id="chatbotBadge">1</span>
  </button>
</div>
<?php endif; ?>

<script src="<?= $base ?>assets/js/chatbot.js"></script>
</body>
</html>
