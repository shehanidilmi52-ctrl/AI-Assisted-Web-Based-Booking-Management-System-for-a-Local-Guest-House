<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$current_page = basename($_SERVER['PHP_SELF'], '.php');
$is_admin = strpos($_SERVER['PHP_SELF'], '/admin/') !== false;
// Base path relative to the rashmika/ root
$script = str_replace('\\','/',$_SERVER['PHP_SELF']);
// Find how deep we are inside rashmika/
$parts = explode('/', trim($script, '/'));
$idx   = array_search('rashmika', $parts);
$depth = ($idx !== false) ? count($parts) - $idx - 2 : 1;
$base  = str_repeat('../', max(1, $depth));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($page_title) ? htmlspecialchars($page_title) . ' — ' : '' ?>Rashmika Home Stay</title>
  <link rel="stylesheet" href="<?= $base ?>assets/css/style.css">
</head>
<body>

<?php if (!$is_admin): ?>
<nav class="navbar">
  <a href="<?= $base ?>pages/index.php" class="navbar-brand">
    <div class="brand-icon"></div>
    <div>
      <span class="brand-name">Rashmika Home Stay</span>
      <span class="brand-sub">Maskeliya, Nuwara Eliya</span>
    </div>
  </a>
  <button class="nav-toggle" id="navToggle" aria-label="Menu">&#9776;</button>
  <nav class="navbar-nav" id="navMenu">
    <a href="<?= $base ?>pages/index.php"       <?= $current_page==='index'       ?'class="active"':'' ?>>Home</a>
    <a href="<?= $base ?>pages/rooms.php"       <?= $current_page==='rooms'       ?'class="active"':'' ?>>Rooms</a>
    <?php if (isset($_SESSION['user_id'])): ?>
      <a href="<?= $base ?>pages/my-bookings.php" <?= $current_page==='my-bookings' ?'class="active"':'' ?>>My Bookings</a>
      <?php if ($_SESSION['role'] === 'admin'): ?>
        <a href="<?= $base ?>admin/dashboard.php">Admin ⚙</a>
      <?php endif; ?>
      <a href="<?= $base ?>auth/logout.php" class="btn-nav-cta">Sign Out</a>
    <?php else: ?>
      <a href="<?= $base ?>auth/login.php"      <?= $current_page==='login'       ?'class="active"':'' ?>>Sign In</a>
      <a href="<?= $base ?>auth/register.php" class="btn-nav-cta">Book Now</a>
    <?php endif; ?>
  </nav>
</nav>
<script>
document.getElementById('navToggle')?.addEventListener('click',function(){
  document.getElementById('navMenu').classList.toggle('open');
});
</script>
<?php endif; ?>
