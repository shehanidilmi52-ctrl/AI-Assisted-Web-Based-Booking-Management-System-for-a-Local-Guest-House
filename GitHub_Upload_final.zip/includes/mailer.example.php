<?php
/**
 * EMAIL CONFIGURATION — EXAMPLE FILE
 * ====================================
 * Copy this file to  includes/mailer.php  and fill in your Gmail credentials.
 * NEVER commit  includes/mailer.php  to version control.
 *
 * HOW TO SET UP GMAIL APP PASSWORD:
 * 1. Enable 2-Step Verification on your Google account:
 *    https://myaccount.google.com/security
 * 2. Go to: https://myaccount.google.com/apppasswords
 * 3. Select app → "Mail", device → "Other (Windows Computer)"
 * 4. Copy the 16-character app password shown (spaces are fine at runtime)
 * 5. Paste it into GMAIL_PASS below (between the quotes)
 *
 * PHPMailer setup:
 *   Place these 3 files inside  includes/PHPMailer/src/
 *     PHPMailer.php   SMTP.php   Exception.php
 *   Download from: https://github.com/PHPMailer/PHPMailer/tree/master/src
 */

define('HOMESTAY_EMAIL', 'your-email@gmail.com');   // ← replace with your Gmail
define('HOMESTAY_NAME',  'Rashmika Home Stay');

// Gmail SMTP credentials
define('GMAIL_USER', 'your-email@gmail.com');        // ← replace with your Gmail
define('GMAIL_PASS', 'xxxx xxxx xxxx xxxx');         // ← replace with 16-char App Password

// ─────────────────────────────────────────────────────────────────────────────
// Everything below this line is the same as the working mailer.php — do not edit
// ─────────────────────────────────────────────────────────────────────────────

function rhs_send_email(string $to_email, string $to_name, string $subject, string $html_body): bool {
    $result = false;
    $method = 'none';

    $pm = __DIR__ . '/PHPMailer/src/PHPMailer.php';
    if (file_exists($pm)) {
        require_once $pm;
        require_once __DIR__ . '/PHPMailer/src/SMTP.php';
        require_once __DIR__ . '/PHPMailer/src/Exception.php';
        try {
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = GMAIL_USER;
            $mail->Password   = GMAIL_PASS;
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;
            $mail->CharSet    = 'UTF-8';
            $mail->setFrom(GMAIL_USER, HOMESTAY_NAME);
            $mail->addAddress($to_email, $to_name);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $html_body;
            $mail->AltBody = strip_tags($html_body);
            $mail->send();
            $result = true;
            $method = 'PHPMailer/SMTP';
        } catch (Exception $e) {
            $method = 'PHPMailer failed: ' . $e->getMessage();
        }
    }

    if (!$result) {
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: " . HOMESTAY_NAME . " <" . GMAIL_USER . ">\r\n";
        $headers .= "Reply-To: " . GMAIL_USER . "\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion();
        $result  = @mail($to_email, $subject, $html_body, $headers);
        $method  = $result ? 'mail()' : 'mail() failed';
    }

    $log_dir = __DIR__ . '/../logs';
    if (!is_dir($log_dir)) @mkdir($log_dir, 0755, true);
    $log = "[" . date('Y-m-d H:i:s') . "] TO: {$to_email} | SUBJECT: {$subject} | METHOD: {$method} | SENT: " . ($result ? 'YES' : 'NO') . "\n";
    @file_put_contents($log_dir . '/email_log.txt', $log, FILE_APPEND);

    return $result;
}

function email_booking_confirmed(array $booking): bool {
    $ref     = str_pad($booking['id'], 4, '0', STR_PAD_LEFT);
    $guest   = htmlspecialchars($booking['guest_name']);
    $room    = 'Room ' . htmlspecialchars($booking['room_number']) . ' — ' . htmlspecialchars($booking['room_type']);
    $checkin = date('d M Y', strtotime($booking['check_in']));
    $checkout= date('d M Y', strtotime($booking['check_out']));
    $nights  = max(1, (strtotime($booking['check_out']) - strtotime($booking['check_in'])) / 86400);
    $total   = 'Rs. ' . number_format($booking['total_price']);
    $subject = "Booking Confirmed — #{$ref} | Rashmika Home Stay";
    $body    = email_template("Your booking is confirmed!", "
        <p>Dear <strong>{$guest}</strong>,</p>
        <p>Thank you for choosing Rashmika Home Stay. Your booking has been <strong style='color:#2A7090;'>confirmed</strong>.</p>
        " . email_summary_table([
            'Booking Reference' => "#$ref",
            'Room'              => $room,
            'Check-in'         => $checkin,
            'Check-out'        => $checkout,
            'Nights'           => $nights,
            'Total Amount'     => $total,
        ]) . "
        <p>We look forward to welcoming you to Maskeliya, the gateway to Adam's Peak!</p>
        <p style='margin-top:1.5rem;'>For any questions, contact us:<br>
        Phone: +94 77 712 3456<br>
        Email: info@rashmikahomestay.lk</p>
    ");
    return rhs_send_email($booking['guest_email'], $booking['guest_name'], $subject, $body);
}

function email_booking_pending(array $booking): bool {
    $ref     = str_pad($booking['id'], 4, '0', STR_PAD_LEFT);
    $guest   = htmlspecialchars($booking['guest_name']);
    $room    = 'Room ' . htmlspecialchars($booking['room_number']) . ' — ' . htmlspecialchars($booking['room_type']);
    $checkin = date('d M Y', strtotime($booking['check_in']));
    $checkout= date('d M Y', strtotime($booking['check_out']));
    $total   = 'Rs. ' . number_format($booking['total_price']);
    $subject = "Booking Received — #{$ref} | Rashmika Home Stay";
    $body    = email_template("We received your booking!", "
        <p>Dear <strong>{$guest}</strong>,</p>
        <p>Thank you for your booking at Rashmika Home Stay. Your reservation is currently <strong style='color:#E6A817;'>pending confirmation</strong>. We will confirm it shortly.</p>
        " . email_summary_table([
            'Booking Reference' => "#$ref",
            'Room'              => $room,
            'Check-in'         => $checkin,
            'Check-out'        => $checkout,
            'Total Amount'     => $total,
        ]) . "
        <p>If you have any questions, please contact us at +94 77 712 3456.</p>
    ");
    return rhs_send_email($booking['guest_email'], $booking['guest_name'], $subject, $body);
}

function email_booking_cancelled(array $booking): bool {
    $ref   = str_pad($booking['id'], 4, '0', STR_PAD_LEFT);
    $guest = htmlspecialchars($booking['guest_name']);
    $room  = 'Room ' . htmlspecialchars($booking['room_number']) . ' — ' . htmlspecialchars($booking['room_type']);
    $subject = "Booking Cancelled — #{$ref} | Rashmika Home Stay";
    $body    = email_template("Your booking has been cancelled", "
        <p>Dear <strong>{$guest}</strong>,</p>
        <p>Your booking <strong>#{$ref}</strong> for <strong>{$room}</strong> has been <strong style='color:#D94F4F;'>cancelled</strong>.</p>
        <p>If this was a mistake or you would like to make a new booking, please visit our website or contact us:</p>
        <p>Phone: +94 77 712 3456<br>Email: info@rashmikahomestay.lk</p>
        <p>We hope to welcome you to Rashmika Home Stay in the future!</p>
    ");
    return rhs_send_email($booking['guest_email'], $booking['guest_name'], $subject, $body);
}

function email_status_changed(array $booking, string $new_status): bool {
    switch ($new_status) {
        case 'confirmed': return email_booking_confirmed($booking);
        case 'cancelled': return email_booking_cancelled($booking);
        default:          return false;
    }
}

function email_template(string $heading, string $content): string {
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#f0f8fb;font-family:Arial,sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0f8fb;padding:30px 0;">
      <tr><td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.08);">
          <tr><td style="background:linear-gradient(135deg,#1A3C4D,#2A7090);padding:28px 36px;text-align:center;">
            <div style="font-size:22px;font-weight:700;color:#ffffff;letter-spacing:0.5px;">Rashmika Home Stay</div>
            <div style="font-size:12px;color:rgba(255,255,255,.7);margin-top:4px;">Maskeliya, Nuwara Eliya — Gateway to Adam\'s Peak</div>
          </td></tr>
          <tr><td style="padding:28px 36px 0;text-align:center;">
            <h2 style="margin:0;font-size:20px;color:#1A3C4D;">' . htmlspecialchars($heading) . '</h2>
            <div style="width:48px;height:3px;background:#2A7090;margin:12px auto 0;border-radius:2px;"></div>
          </td></tr>
          <tr><td style="padding:24px 36px;font-size:14px;color:#3a4a52;line-height:1.7;">' . $content . '</td></tr>
          <tr><td style="background:#f0f8fb;padding:20px 36px;text-align:center;font-size:12px;color:#607D8B;">
            Nallathanniya Road, Laxapana Estate, Maskeliya, Nuwara Eliya<br>
            &copy; ' . date('Y') . ' Rashmika Home Stay. All rights reserved.
          </td></tr>
        </table>
      </td></tr>
    </table>
    </body></html>';
}

function email_summary_table(array $rows): string {
    $html = '<table width="100%" cellpadding="0" cellspacing="0" style="margin:20px 0;border:1px solid #d6eef5;border-radius:8px;overflow:hidden;">';
    foreach ($rows as $label => $value) {
        $html .= '<tr>
            <td style="padding:10px 16px;background:#f0f8fb;font-size:13px;color:#607D8B;width:40%;">' . htmlspecialchars($label) . '</td>
            <td style="padding:10px 16px;font-size:13px;color:#1A3C4D;font-weight:600;">' . $value . '</td>
        </tr>';
    }
    $html .= '</table>';
    return $html;
}
