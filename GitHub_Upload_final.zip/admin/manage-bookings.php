<?php
session_start();
if (!isset($_SESSION['user_id'])||$_SESSION['role']!=='admin') { header("Location: ../auth/login.php"); exit; }
include '../config/db.php';
$page_title = 'Manage Bookings';

$status_filter = $_GET['status'] ?? '';
$search        = trim($_GET['q'] ?? '');
$sql = "SELECT b.*,u.name AS guest_name,u.email AS guest_email,r.room_number,r.room_type
        FROM bookings b JOIN users u ON b.user_id=u.id JOIN rooms r ON b.room_id=r.id WHERE 1=1";
$params=[];
if ($status_filter) { $sql.=" AND b.status=?"; $params[]=$status_filter; }
if ($search)        { $sql.=" AND (u.name LIKE ? OR u.email LIKE ? OR r.room_number LIKE ?)"; $params[]="%$search%"; $params[]="%$search%"; $params[]="%$search%"; }
$sql.=" ORDER BY b.created_at DESC";
try { $bookings=$pdo->prepare($sql); $bookings->execute($params); $bookings=$bookings->fetchAll(); }
catch(Exception $e){ $bookings=[]; }
$msg = $_GET['msg']??'';
?>
<!DOCTYPE html><html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Bookings — Rashmika Admin</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="admin-wrapper">
  <?php include '_sidebar.php'; ?>
  <div class="admin-main">
    <div class="admin-topbar">
      <div class="admin-topbar-title"><h2>Manage Bookings</h2></div>
      <div class="admin-topbar-right">
        <span style="font-size:.85rem;color:var(--grey-mid);"><?= count($bookings) ?> booking<?= count($bookings)!=1?'s':'' ?></span>
      </div>
    </div>
    <div class="admin-content">
      <?php if($msg==='updated'): ?><div class="alert alert-success">Booking status updated successfully.</div><?php endif; ?>

      <!-- Filters -->
      <form method="GET" style="display:flex;gap:1rem;flex-wrap:wrap;align-items:flex-end;margin-bottom:1.5rem;">
        <div class="table-search" style="flex:1;min-width:200px;">
          <input type="text" name="q" class="form-control" placeholder="Search by guest name or room…" value="<?= htmlspecialchars($search) ?>">
        </div>
        <select name="status" class="form-control" style="max-width:160px;">
          <option value="">All Statuses</option>
          <option value="pending"   <?= $status_filter==='pending'  ?'selected':'' ?>>Pending</option>
          <option value="confirmed" <?= $status_filter==='confirmed'?'selected':'' ?>>Confirmed</option>
          <option value="cancelled" <?= $status_filter==='cancelled'?'selected':'' ?>>Cancelled</option>
        </select>
        <button type="submit" class="btn btn-teal">Filter</button>
        <?php if($status_filter||$search): ?><a href="manage-bookings.php" class="btn btn-ghost">Clear</a><?php endif; ?>
      </form>

      <?php if(empty($bookings)): ?>
        <div class="empty-state data-card"><div class="empty-icon">📋</div><h3>No bookings found</h3></div>
      <?php else: ?>
        <div class="data-card">
          <div class="table-wrap">
            <table>
              <thead><tr><th>#</th><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Nights</th><th>Total</th><th>Status</th><th>Action</th></tr></thead>
              <tbody>
              <?php foreach($bookings as $b):
                $nights=max(1,(strtotime($b['check_out'])-strtotime($b['check_in']))/86400);
              ?>
                <tr>
                  <td><code style="color:var(--teal-mid);">#<?= str_pad($b['id'],4,'0',STR_PAD_LEFT) ?></code></td>
                  <td>
                    <div style="font-weight:600;"><?= htmlspecialchars($b['guest_name']) ?></div>
                    <div style="font-size:.78rem;color:var(--grey-mid);"><?= htmlspecialchars($b['guest_email']) ?></div>
                  </td>
                  <td>Room <?= htmlspecialchars($b['room_number']) ?><br><span style="font-size:.78rem;color:var(--grey-mid);"><?= htmlspecialchars($b['room_type']) ?></span></td>
                  <td><?= date('d M Y', strtotime($b['check_in'])) ?></td>
                  <td><?= date('d M Y', strtotime($b['check_out'])) ?></td>
                  <td style="text-align:center;"><?= $nights ?></td>
                  <td style="font-weight:600;color:var(--coral);">Rs.<?= number_format($b['total_price']) ?></td>
                  <td><span class="table-badge <?= $b['status'] ?>"><?= ucfirst($b['status']) ?></span></td>
                  <td><a href="update-booking.php?id=<?= $b['id'] ?>" class="btn btn-teal btn-sm">Update</a></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
</body></html>
