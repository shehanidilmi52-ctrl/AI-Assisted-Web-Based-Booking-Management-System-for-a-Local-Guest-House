<?php
session_start();
if (!isset($_SESSION['user_id'])||$_SESSION['role']!=='admin') { header("Location: ../auth/login.php"); exit; }
include '../config/db.php';
$page_title = 'Manage Guests';
$search = trim($_GET['q']??'');
try {
    $sql="SELECT u.*,(SELECT COUNT(*) FROM bookings b WHERE b.user_id=u.id) AS booking_count FROM users u WHERE u.role='customer'";
    $params=[];
    if($search){ $sql.=" AND (u.name LIKE ? OR u.email LIKE ?)"; $params[]="%$search%"; $params[]="%$search%"; }
    $sql.=" ORDER BY u.created_at DESC";
    $stmt=$pdo->prepare($sql); $stmt->execute($params);
    $users=$stmt->fetchAll();
} catch(Exception $e){ $users=[]; }
?>
<!DOCTYPE html><html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Guests — Rashmika Admin</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="admin-wrapper">
  <?php include '_sidebar.php'; ?>
  <div class="admin-main">
    <div class="admin-topbar">
      <div class="admin-topbar-title"><h2>Registered Guests</h2></div>
      <div class="admin-topbar-right">
        <span style="font-size:.85rem;color:var(--grey-mid);"><?= count($users) ?> guest<?= count($users)!=1?'s':'' ?></span>
      </div>
    </div>
    <div class="admin-content">
      <form method="GET" style="margin-bottom:1.5rem;">
        <div class="table-search" style="max-width:360px;">
          <input type="text" name="q" class="form-control" placeholder="Search by name or email…" value="<?= htmlspecialchars($search) ?>">
        </div>
      </form>
      <div class="data-card">
        <?php if(empty($users)): ?>
          <div class="empty-state" style="padding:2rem;"><div class="empty-icon">👥</div><h3>No guests found</h3></div>
        <?php else: ?>
          <div class="table-wrap">
            <table>
              <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Bookings</th><th>Joined</th></tr></thead>
              <tbody>
              <?php foreach($users as $i=>$u): ?>
                <tr>
                  <td style="color:var(--grey-mid);font-size:.82rem;"><?= $i+1 ?></td>
                  <td><strong><?= htmlspecialchars($u['name']) ?></strong></td>
                  <td style="color:var(--grey-mid);"><?= htmlspecialchars($u['email']) ?></td>
                  <td><span class="table-badge <?= $u['booking_count']>0?'confirmed':'pending' ?>"><?= $u['booking_count'] ?> booking<?= $u['booking_count']!=1?'s':'' ?></span></td>
                  <td style="color:var(--grey-mid);font-size:.85rem;"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</body></html>
