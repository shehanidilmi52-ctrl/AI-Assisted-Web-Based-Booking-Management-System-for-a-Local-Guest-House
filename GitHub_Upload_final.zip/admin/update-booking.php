<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php"); exit;
}
include '../config/db.php';
include '../includes/mailer.php';

$id = (int)($_GET['id'] ?? 0);
$error = '';

try {
    $stmt = $pdo->prepare("
        SELECT b.*, u.name AS guest_name, u.email AS guest_email, r.room_number, r.room_type
        FROM bookings b JOIN users u ON b.user_id=u.id JOIN rooms r ON b.room_id=r.id
        WHERE b.id=?
    ");
    $stmt->execute([$id]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) { $booking = null; }

if (!$booking) {
    header("Location: manage-bookings.php"); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = $_POST['status'] ?? '';
    $allowed = ['pending','confirmed','cancelled'];
    if (in_array($new_status, $allowed)) {
        try {
            $pdo->prepare("UPDATE bookings SET status=? WHERE id=?")->execute([$new_status, $id]);

            // Send email notification to guest about status change
            try {
                $bk_stmt = $pdo->prepare("
                    SELECT b.*, u.name AS guest_name, u.email AS guest_email,
                           r.room_number, r.room_type
                    FROM bookings b
                    JOIN users u ON b.user_id = u.id
                    JOIN rooms  r ON b.room_id  = r.id
                    WHERE b.id = ?
                ");
                $bk_stmt->execute([$id]);
                $bk = $bk_stmt->fetch(PDO::FETCH_ASSOC);
                if ($bk) email_status_changed($bk, $new_status);
            } catch (Exception $em) { /* email failure must not break update */ }

            header("Location: manage-bookings.php?msg=updated"); exit;
        } catch (Exception $e) {
            $error = "Update failed. Please try again.";
        }
    }
}
$nights = (strtotime($booking['check_out'])-strtotime($booking['check_in']))/86400;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Booking — Admin</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="admin-wrapper">
  <?php include '_sidebar.php'; ?>
  <div class="admin-main">
    <div class="admin-topbar">
      <div class="admin-topbar-title"><h2>Update Booking #<?= str_pad($id,4,'0',STR_PAD_LEFT) ?></h2></div>
      <div class="admin-topbar-right">
        <a href="manage-bookings.php" class="btn btn-ghost btn-sm">← Back</a>
      </div>
    </div>
    <div class="admin-content">

      <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php endif; ?>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; max-width:900px;">

        <!-- Booking details -->
        <div class="data-card">
          <div class="data-card-header"><h3>Booking Details</h3></div>
          <div style="padding:1.25rem;">
            <div class="summary-row" style="border-bottom:1px solid var(--grey-light); padding:0.6rem 0;">
              <span style="color:var(--grey-mid); font-size:0.85rem;">Reference</span>
              <span><code>#<?= str_pad($id,4,'0',STR_PAD_LEFT) ?></code></span>
            </div>
            <div class="summary-row" style="border-bottom:1px solid var(--grey-light); padding:0.6rem 0;">
              <span style="color:var(--grey-mid); font-size:0.85rem;">Guest</span>
              <span><?= htmlspecialchars($booking['guest_name']) ?></span>
            </div>
            <div class="summary-row" style="border-bottom:1px solid var(--grey-light); padding:0.6rem 0;">
              <span style="color:var(--grey-mid); font-size:0.85rem;">Email</span>
              <span><?= htmlspecialchars($booking['guest_email']) ?></span>
            </div>
            <div class="summary-row" style="border-bottom:1px solid var(--grey-light); padding:0.6rem 0;">
              <span style="color:var(--grey-mid); font-size:0.85rem;">Room</span>
              <span>Room <?= htmlspecialchars($booking['room_number']) ?> (<?= htmlspecialchars($booking['room_type']) ?>)</span>
            </div>
            <div class="summary-row" style="border-bottom:1px solid var(--grey-light); padding:0.6rem 0;">
              <span style="color:var(--grey-mid); font-size:0.85rem;">Check-in</span>
              <span><?= date('d M Y', strtotime($booking['check_in'])) ?></span>
            </div>
            <div class="summary-row" style="border-bottom:1px solid var(--grey-light); padding:0.6rem 0;">
              <span style="color:var(--grey-mid); font-size:0.85rem;">Check-out</span>
              <span><?= date('d M Y', strtotime($booking['check_out'])) ?></span>
            </div>
            <div class="summary-row" style="border-bottom:1px solid var(--grey-light); padding:0.6rem 0;">
              <span style="color:var(--grey-mid); font-size:0.85rem;">Nights</span>
              <span><?= $nights ?></span>
            </div>
            <div class="summary-row" style="padding:0.6rem 0;">
              <span style="color:var(--grey-mid); font-size:0.85rem;">Total</span>
              <strong>Rs. <?= number_format($booking['total_price']) ?></strong>
            </div>
            <?php if (!empty($booking['special_requests'])): ?>
            <div style="margin-top:1rem; padding:0.75rem; background:var(--ivory); border-radius:var(--radius-sm);">
              <div style="font-size:0.78rem; color:var(--grey-mid); margin-bottom:0.25rem;">Special requests</div>
              <div style="font-size:0.88rem;"><?= htmlspecialchars($booking['special_requests']) ?></div>
            </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Status update -->
        <div class="data-card">
          <div class="data-card-header"><h3>Update Status</h3></div>
          <div style="padding:1.25rem;">
            <div style="margin-bottom:1.25rem;">
              <span style="font-size:0.85rem; color:var(--grey-mid);">Current status</span><br>
              <span class="table-badge <?= strtolower($booking['status']) ?>" style="margin-top:0.4rem; display:inline-block;"><?= ucfirst($booking['status']) ?></span>
            </div>
            <form method="POST">
              <div class="form-group">
                <label class="form-label" for="status">Change to</label>
                <select name="status" id="status" class="form-control">
                  <option value="pending"   <?= $booking['status']==='pending'?'selected':'' ?>>Pending</option>
                  <option value="confirmed" <?= $booking['status']==='confirmed'?'selected':'' ?>>Confirmed</option>
                  <option value="cancelled" <?= $booking['status']==='cancelled'?'selected':'' ?>>Cancelled</option>
                </select>
              </div>
              <button type="submit" class="btn btn-green" style="width:100%; justify-content:center;">
                Save Changes
              </button>
            </form>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>
</body>
</html>
