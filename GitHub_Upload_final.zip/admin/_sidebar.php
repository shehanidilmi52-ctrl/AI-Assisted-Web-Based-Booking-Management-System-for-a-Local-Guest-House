<?php
// Reusable admin sidebar — include in every admin page
$current_admin = basename($_SERVER['PHP_SELF'], '.php');
try {
    $pending_count = $pdo->query("SELECT COUNT(*) FROM bookings WHERE status='pending'")->fetchColumn();
} catch (Exception $e) { $pending_count = 0; }
?>
<aside class="admin-sidebar">
  <div class="admin-sidebar-header">
    <div class="admin-sidebar-brand">
      <div class="brand-dot"></div>
      Rashmika Home Stay
    </div>
    <div style="font-size:0.72rem; color:rgba(255,255,255,0.4); margin-top:4px;">Admin Panel</div>
  </div>

  <div class="admin-sidebar-label">Main</div>
  <nav class="admin-nav">
    <a href="dashboard.php" <?= $current_admin==='dashboard'?'class="active"':'' ?>>
      <span class="nav-icon">📊</span> Dashboard
    </a>
    <a href="manage-bookings.php" <?= $current_admin==='manage-bookings'?'class="active"':'' ?>>
      <span class="nav-icon">📋</span> Bookings
      <?php if ($pending_count > 0): ?>
        <span style="background:var(--gold);color:var(--green-deep);font-size:0.7rem;font-weight:700;padding:1px 6px;border-radius:10px;margin-left:auto;"><?= $pending_count ?></span>
      <?php endif; ?>
    </a>
    <a href="manage-rooms.php" <?= $current_admin==='manage-rooms'?'class="active"':'' ?>>
      <span class="nav-icon">🛏</span> Rooms
    </a>
    <a href="manage-users.php" <?= $current_admin==='manage-users'?'class="active"':'' ?>>
      <span class="nav-icon">👥</span> Guests
    </a>
  </nav>

  <div class="admin-sidebar-label">System</div>
  <nav class="admin-nav">
    <a href="../pages/index.php">
      <span class="nav-icon">🌐</span> View Site
    </a>
    <a href="../auth/logout.php">
      <span class="nav-icon">🚪</span> Sign Out
    </a>
  </nav>

  <div class="admin-sidebar-footer">
    Signed in as<br>
    <strong style="color:rgba(255,255,255,0.7);"><?= htmlspecialchars($_SESSION['name'] ?? 'Admin') ?></strong>
  </div>
</aside>
