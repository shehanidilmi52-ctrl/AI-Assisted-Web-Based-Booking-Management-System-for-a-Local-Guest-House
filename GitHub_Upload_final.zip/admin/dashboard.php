<?php
session_start();
if (!isset($_SESSION['user_id'])||$_SESSION['role']!=='admin') { header("Location: ../auth/login.php"); exit; }
include '../config/db.php';
$page_title = 'Dashboard';
try {
    $total_bookings    = $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
    $pending_bookings  = $pdo->query("SELECT COUNT(*) FROM bookings WHERE status='pending'")->fetchColumn();
    $confirmed_bookings= $pdo->query("SELECT COUNT(*) FROM bookings WHERE status='confirmed'")->fetchColumn();
    $total_rooms       = $pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
    $total_guests      = $pdo->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn();
    $month_revenue     = $pdo->query("SELECT COALESCE(SUM(total_price),0) FROM bookings WHERE status='confirmed' AND MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())")->fetchColumn();
    $recent = $pdo->query("SELECT b.*,u.name AS guest_name,r.room_number,r.room_type FROM bookings b JOIN users u ON b.user_id=u.id JOIN rooms r ON b.room_id=r.id ORDER BY b.created_at DESC LIMIT 8")->fetchAll();
} catch(Exception $e) { $total_bookings=$pending_bookings=$confirmed_bookings=$total_rooms=$total_guests=0; $month_revenue=0; $recent=[]; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard — Rashmika Admin</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="admin-wrapper">
  <?php include '_sidebar.php'; ?>
  <div class="admin-main">
    <div class="admin-topbar">
      <div class="admin-topbar-title">
        <h2>Dashboard</h2>
        <div style="font-size:.8rem;color:var(--grey-mid);">Welcome back, <?= htmlspecialchars($_SESSION['name']) ?> 👋</div>
      </div>
      <div class="admin-topbar-right">
        <span style="font-size:.82rem;color:var(--grey-mid);"><?= date('l, d F Y') ?></span>
        <a href="manage-bookings.php" class="btn btn-primary btn-sm">View All Bookings</a>
      </div>
    </div>
    <div class="admin-content">

      <!-- KPIs -->
      <div class="kpi-grid">
        <div class="kpi-card teal">
          <div class="kpi-icon">📋</div>
          <div class="kpi-label">Total Bookings</div>
          <div class="kpi-value"><?= $total_bookings ?></div>
          <div class="kpi-sub">All time</div>
        </div>
        <div class="kpi-card coral">
          <div class="kpi-icon">⏳</div>
          <div class="kpi-label">Pending</div>
          <div class="kpi-value"><?= $pending_bookings ?></div>
          <div class="kpi-sub">Awaiting confirmation</div>
        </div>
        <div class="kpi-card green">
          <div class="kpi-icon">✅</div>
          <div class="kpi-label">Confirmed</div>
          <div class="kpi-value"><?= $confirmed_bookings ?></div>
          <div class="kpi-sub">Active bookings</div>
        </div>
        <div class="kpi-card teal">
          <div class="kpi-icon">🛏</div>
          <div class="kpi-label">Total Rooms</div>
          <div class="kpi-value"><?= $total_rooms ?></div>
          <div class="kpi-sub">In property</div>
        </div>
        <div class="kpi-card gold">
          <div class="kpi-icon">👥</div>
          <div class="kpi-label">Registered Guests</div>
          <div class="kpi-value"><?= $total_guests ?></div>
          <div class="kpi-sub">All time</div>
        </div>
        <div class="kpi-card green">
          <div class="kpi-icon">💰</div>
          <div class="kpi-label">Revenue (This Month)</div>
          <div class="kpi-value" style="font-size:1.4rem;">Rs.<?= number_format($month_revenue) ?></div>
          <div class="kpi-sub">Confirmed bookings only</div>
        </div>
      </div>

      <!-- Recent Bookings -->
      <div class="data-card">
        <div class="data-card-header">
          <h3>Recent Bookings</h3>
          <a href="manage-bookings.php" class="btn btn-ghost btn-sm">View All →</a>
        </div>
        <?php if(empty($recent)): ?>
          <div class="empty-state" style="padding:2rem;"><div class="empty-icon">📋</div><h3>No bookings yet</h3></div>
        <?php else: ?>
          <div class="table-wrap">
            <table>
              <thead><tr><th>#</th><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Total</th><th>Status</th><th>Action</th></tr></thead>
              <tbody>
              <?php foreach($recent as $b): ?>
                <tr>
                  <td><code>#<?= str_pad($b['id'],4,'0',STR_PAD_LEFT) ?></code></td>
                  <td><?= htmlspecialchars($b['guest_name']) ?></td>
                  <td>Room <?= htmlspecialchars($b['room_number']) ?></td>
                  <td><?= date('d M Y', strtotime($b['check_in'])) ?></td>
                  <td><?= date('d M Y', strtotime($b['check_out'])) ?></td>
                  <td>Rs.<?= number_format($b['total_price']) ?></td>
                  <td><span class="table-badge <?= $b['status'] ?>"><?= ucfirst($b['status']) ?></span></td>
                  <td><a href="update-booking.php?id=<?= $b['id'] ?>" class="btn btn-teal btn-sm">Update</a></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

    </div>
  </div>
</div>
</body></html>
