<?php
session_start();
if (!isset($_SESSION['user_id'])||$_SESSION['role']!=='admin') { header("Location: ../auth/login.php"); exit; }
include '../config/db.php';
$page_title = 'Manage Rooms';
$error=''; $success='';

// Add room
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['action'])&&$_POST['action']==='add'){
    $rnum = trim($_POST['room_number']??'');
    $rtype= trim($_POST['room_type']??'');
    $price= (float)($_POST['price_per_night']??0);
    $cap  = (int)($_POST['capacity']??1);
    $desc = trim($_POST['description']??'');
    $status=in_array($_POST['status']??'',['available','unavailable'])?$_POST['status']:'available';
    if(!$rnum||!$rtype||!$price){ $error="Please fill all required fields."; }
    else {
        try {
            $pdo->prepare("INSERT INTO rooms (room_number,room_type,price_per_night,capacity,description,status) VALUES(?,?,?,?,?,?)")
                ->execute([$rnum,$rtype,$price,$cap,$desc,$status]);
            $success="Room added successfully.";
        } catch(Exception $e){ $error="Room number already exists or error: ".$e->getMessage(); }
    }
}
// Toggle status
if(isset($_GET['toggle'])){
    try{
        $r=$pdo->prepare("SELECT status FROM rooms WHERE id=?");$r->execute([(int)$_GET['toggle']]);
        $cur=$r->fetchColumn();
        $pdo->prepare("UPDATE rooms SET status=? WHERE id=?")->execute([$cur==='available'?'unavailable':'available',(int)$_GET['toggle']]);
        header("Location: manage-rooms.php?updated=1");exit;
    }catch(Exception $e){}
}
try{ $rooms=$pdo->query("SELECT * FROM rooms ORDER BY room_number")->fetchAll(); }
catch(Exception $e){ $rooms=[]; }
?>
<!DOCTYPE html><html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Rooms — Rashmika Admin</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="admin-wrapper">
  <?php include '_sidebar.php'; ?>
  <div class="admin-main">
    <div class="admin-topbar">
      <div class="admin-topbar-title"><h2>Manage Rooms</h2></div>
      <div class="admin-topbar-right">
        <button class="btn btn-primary btn-sm" onclick="document.getElementById('addModal').style.display='flex'">+ Add Room</button>
      </div>
    </div>
    <div class="admin-content">
      <?php if($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
      <?php if($error):   ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
      <?php if(isset($_GET['updated'])): ?><div class="alert alert-success">Room status updated.</div><?php endif; ?>

      <div class="rooms-grid">
      <?php foreach($rooms as $r):
        $icons=['Double Room'=>'🛏','Family Room'=>'🏠','Deluxe Room'=>'✨'];
        $icon=$icons[$r['room_type']]??'🏨';
        $avail=$r['status']==='available';
      ?>
        <div class="room-card">
          <div class="room-img"><?= $icon ?>
            <span class="room-badge <?= $avail?'':'unavailable' ?>"><?= $avail?'Available':'Unavailable' ?></span>
          </div>
          <div class="room-body">
            <div class="room-type"><?= htmlspecialchars($r['room_type']) ?></div>
            <div class="room-name">Room <?= htmlspecialchars($r['room_number']) ?></div>
            <div class="room-desc"><?= htmlspecialchars($r['description']??'No description.') ?></div>
            <div class="room-amenities">
              <span class="amenity-pill">👥 <?= $r['capacity'] ?> guests</span>
            </div>
            <div class="room-footer">
              <div class="room-price">
                <span class="amount">Rs.<?= number_format($r['price_per_night']) ?></span>
                <span class="unit">per night</span>
              </div>
              <a href="manage-rooms.php?toggle=<?= $r['id'] ?>"
                 class="btn btn-sm <?= $avail?'btn-danger':'btn-green' ?>"
                 onclick="return confirm('Toggle status for Room <?= $r['room_number'] ?>?')">
                <?= $avail?'Mark Unavailable':'Mark Available' ?>
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- Add Room Modal -->
<div id="addModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9000;align-items:center;justify-content:center;padding:1rem;">
  <div class="form-card form-card-wide" style="max-width:520px;width:100%;max-height:90vh;overflow-y:auto;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;">
      <h3 style="color:var(--teal-deep);">Add New Room</h3>
      <button onclick="document.getElementById('addModal').style.display='none'" style="background:none;border:none;font-size:1.3rem;color:var(--grey-mid);cursor:pointer;">✕</button>
    </div>
    <?php if($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
    <form method="POST">
      <input type="hidden" name="action" value="add">
      <div class="form-row">
        <div class="form-group"><label class="form-label">Room Number *</label><input type="text" name="room_number" class="form-control" placeholder="e.g. 105" required></div>
        <div class="form-group"><label class="form-label">Capacity (guests) *</label><input type="number" name="capacity" class="form-control" value="2" min="1" max="10" required></div>
      </div>
      <div class="form-group">
        <label class="form-label">Room Type *</label>
        <select name="room_type" class="form-control" required>
          <option value="">— Select type —</option>
          <option value="Double Room">Double Room</option>
          <option value="Family Room">Family Room</option>
          <option value="Deluxe Room">Deluxe Room</option>
        </select>
      </div>
      <div class="form-group"><label class="form-label">Price per Night (LKR) *</label><input type="number" name="price_per_night" class="form-control" placeholder="e.g. 5000" min="0" step="100" required></div>
      <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="2" placeholder="Brief description of the room…"></textarea></div>
      <div class="form-group">
        <label class="form-label">Status</label>
        <select name="status" class="form-control"><option value="available">Available</option><option value="unavailable">Unavailable</option></select>
      </div>
      <button type="submit" class="btn btn-primary w-full">Add Room</button>
    </form>
  </div>
</div>
<?php if($error): ?><script>document.getElementById('addModal').style.display='flex';</script><?php endif; ?>
</body></html>
