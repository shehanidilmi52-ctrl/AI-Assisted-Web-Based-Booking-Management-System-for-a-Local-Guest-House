// Rashmika Home Stay — AI Chatbot (rule-based)
(function () {
  const toggle  = document.getElementById('chatbotToggle');
  const window_ = document.getElementById('chatbotWindow');
  const close   = document.getElementById('chatbotClose');
  const input   = document.getElementById('chatbotInput');
  const sendBtn = document.getElementById('chatbotSend');
  const msgs    = document.getElementById('chatbotMessages');
  const badge   = toggle ? toggle.querySelector('.chatbot-badge') : null;

  if (!toggle) return;

  toggle.addEventListener('click', () => {
    window_.classList.toggle('open');
    if (badge) badge.style.display = 'none';
  });
  close.addEventListener('click', () => window_.classList.remove('open'));

  // Knowledge base — Rashmika Home Stay, Maskeliya (Adam's Peak)
  const kb = [
    // Greetings
    { k: ['hello','hi','hey','good morning','good afternoon','good evening','greet','start'], r: "Hello! Welcome to Rashmika Home Stay — your base camp for Adam's Peak. I can help with rooms, pricing, trail info, nearby attractions, transport, weather and more. What would you like to know?" },

    // Rooms & Pricing
    { k: ['price','cost','rate','charge','how much','fee','tariff'], r: "Our room rates per night:\n• Double Room with Shared Bathroom — Rs. 2,500\n• Double Room (en-suite) — Rs. 4,000\n• Family Room (up to 4 guests) — Rs. 6,500\n• Deluxe Room — Rs. 8,000\nBook directly for the best price — no commission fees!" },
    { k: ['room','rooms','type','available','availability','reserve','book'], r: "We have 4 room types: Double Room with Shared Bathroom (Rs. 2,500), Double Room (Rs. 4,000), Family Room (Rs. 6,500), and Deluxe Room (Rs. 8,000). All rooms include free Wi-Fi and warm bedding. Check availability and book instantly on our Rooms page!" },

    // Check-in / Check-out
    { k: ['check.in','check in','arrival','arrive','early check'], r: "Check-in time is from 2:00 PM. If you need an early check-in, please mention it in the Special Requests field when booking and we'll do our best to accommodate." },
    { k: ['check.out','check out','departure','leave','late check'], r: "Check-out time is 11:00 AM. This gives you time to rest and freshen up after your Adam's Peak climb. Late check-out may be possible — just ask us!" },

    // Cancellation
    { k: ['cancel','cancellation','refund','change booking'], r: "You can cancel free of charge up to 24 hours before your check-in date. No credit card is required to book. To cancel, log in to your account and go to My Bookings." },

    // Breakfast & Food
    { k: ['breakfast','meal','eat','hoppers','rice','curry'], r: "We serve an authentic Sri Lankan breakfast from 6:00 AM — perfect before your Adam's Peak climb! Includes rice & curry, hoppers, egg, fresh fruit, juice and tea. Breakfast is included with most room types." },
    { k: ['restaurant','lunch','dinner','food nearby','where to eat'], r: "There are small local restaurants (kadé) near the Nallathanniya trailhead serving rice & curry, noodles and short eats. We can recommend the best local spots during your stay. We also serve breakfast in-house from 6:00 AM." },

    // Wi-Fi & Facilities
    { k: ['wifi','wi-fi','internet','connection','signal'], r: "Free high-speed Wi-Fi is available in all rooms and common areas. Stay connected even in the hill country!" },
    { k: ['ac','air conditioning','heater','fan','warm','cold room'], r: "All rooms have warm bedding and are cosy for the cool mountain nights. The Deluxe Room has air conditioning. Mountain temperatures can drop to 12–15°C at night — pack a warm layer!" },
    { k: ['parking','car','vehicle','park','motorbike'], r: "Free secure on-site parking is available for cars and motorbikes. You can safely leave your vehicle at the homestay while you climb Adam's Peak." },
    { k: ['amenities','facilities','what included','include','towel','hot water'], r: "All rooms include: free Wi-Fi, warm bedding, towels, hot water, and 24/7 security. The Deluxe Room also has AC and a private bathroom. Breakfast is served from 6:00 AM." },

    // Adam's Peak Trail
    { k: ['adam','peak','sri pada','climb','trek','trail','hike','nallathanniya','summit','steps'], r: "We are just 5 minutes from the Nallathanniya trailhead — the main starting point for Adam's Peak (Sri Pada). The trail has about 5,500 steps and takes 3–4 hours one way. Most guests start at 2:00 AM to reach the summit for sunrise. We'll give you a wake-up call!" },
    { k: ['pilgrimage','religious','sacred','holy','footprint','buddhist','hindu','muslim'], r: "Adam's Peak is sacred to Buddhists, Hindus, Muslims and Christians. The 'Sri Pada' (sacred footprint) at the summit is revered by all faiths. It is one of Sri Lanka's most important pilgrimage sites — a truly moving experience." },
    { k: ['distance','how far','km','kilometres','miles','how long to climb'], r: "The Nallathanniya trailhead is about 5 minutes walk from our homestay. The trail to the summit is approximately 7 km with 5,500 steps. Allow 3–4 hours up and 2–3 hours down. Total climb time is 5–7 hours." },

    // Transport & Taxi
    { k: ['taxi','transport','tuk tuk','bus','how to get','getting here','from colombo','from kandy','directions','drive'], r: "From Colombo: approximately 5 hours by car via Hatton (A7 road). From Kandy: approximately 3 hours. The nearest town is Maskeliya. Taxis and tuk-tuks are available from Hatton and Maskeliya to our homestay. We can arrange airport or train station pickup — just contact us at +94 77 712 3456!" },
    { k: ['train','hatton','railway','station'], r: "The nearest railway station is Hatton, about 25 km away on the Colombo–Badulla main line. From Hatton, take a taxi or bus to Maskeliya (about 45 minutes). We can arrange a pickup from Hatton station — call us at +94 77 712 3456." },

    // Nearby Attractions
    { k: ['nearby','attraction','visit','sightseeing','tourist','places','what to see','things to do'], r: "Nearby attractions include:\n• Laxapana Falls — one of Sri Lanka's highest waterfalls (5 km)\n• Castlereagh Reservoir — stunning lake views\n• Norton Bridge — scenic valley\n• Maskeliya tea estates — guided tours available\n• Adam's Peak — just 5 min walk!\nWe can help arrange day trips during your stay." },
    { k: ['laxapana','waterfall','falls'], r: "Laxapana Falls is one of Sri Lanka's highest waterfalls at 126 m, just 5 km from our homestay. It's a beautiful half-day trip — we can give you directions or arrange a tuk-tuk." },
    { k: ['castlereagh','reservoir','lake','maskeliya lake','dam'], r: "The Castlereagh Reservoir is a beautiful lake surrounded by tea estates and forests, just a short drive from our homestay. Perfect for photography and nature walks. The Maskeliya Reservoir (Norton Reservoir) is also nearby." },
    { k: ['tea','estate','plantation','tea factory'], r: "Maskeliya is surrounded by beautiful tea estates. You can walk through the tea gardens, visit a local tea factory, and enjoy the stunning highland scenery. We can point you to the best spots!" },

    // Weather & Best Time
    { k: ['weather','temperature','climate','rain','mist','fog'], r: "Maskeliya is cool and misty year-round. Daytime temperatures are 18–22°C; nights can drop to 10–15°C. The summit of Adam's Peak can be much colder — bring a warm jacket and raincoat. Mornings are often clear and beautiful." },
    { k: ['best time','when to visit','season','pilgrimage season','december','january','february','march','april','may'], r: "The best time to visit is during the pilgrimage season: December to May. The trail is lit with lights and there is a festive atmosphere. We're open year-round — off-season (June–November) is quieter with lower rates and lush green scenery." },

    // Packing Tips
    { k: ['pack','bring','what to wear','packing','shoes','gear','torch','flashlight'], r: "Packing tips for Adam's Peak:\n• Warm jacket or fleece (summit is cold!)\n• Raincoat or poncho\n• Comfortable trekking shoes or trainers\n• Torch / headlamp (climbing starts at 2 AM)\n• Water bottle (1–2 litres)\n• Light snack or energy bar\n• Walking stick (available to hire at the base)\n• Small backpack\nWe provide warm bedding and wake-up calls!" },

    // Languages
    { k: ['language','sinhala','english','tamil','speak','communicate'], r: "Our staff speak Sinhala, English and basic Tamil. We welcome guests from all over the world and will do our best to communicate comfortably in your preferred language." },

    // Group Bookings
    { k: ['group','groups','large group','friends','multiple rooms','how many','10 people','20 people'], r: "We welcome groups! We have 4 rooms that can accommodate up to 12–14 guests total. For larger groups, please contact us directly at +94 77 712 3456 or info@rashmikahomestay.lk and we'll arrange the best combination of rooms for you." },

    // Payment
    { k: ['payment','pay','cash','card','online payment','bank transfer','advance'], r: "Payment is collected on arrival in Sri Lankan Rupees (cash). No advance payment or credit card is required to make a booking online. This makes booking completely risk-free!" },

    // Contact
    { k: ['contact','phone','call','email','reach','whatsapp','message'], r: "You can reach us at:\n• Phone / WhatsApp: +94 77 712 3456\n• Email: info@rashmikahomestay.lk\n• Address: Nallathanniya Road, Laxapana Estate, Maskeliya\nWe're available daily from 7:00 AM to 10:00 PM." },

    // Location
    { k: ['location','address','where','find','map','maskeliya','laxapana','how to find'], r: "We are at Nallathanniya Road, Laxapana Estate, Maskeliya, Nuwara Eliya District. Just 5 minutes walk from the Adam's Peak trailhead. About 5 hours from Colombo and 3 hours from Kandy by road. Search 'Rashmika Home Stay Maskeliya' on Google Maps!" },

    // Family & Children
    { k: ['family','children','kids','child','baby','cot','extra bed'], r: "Families are very welcome! Our Family Room sleeps up to 4 guests comfortably. We can arrange extra beds or cots for small children on request at no extra charge. The Adam's Peak trail is suitable for older children and teenagers." },

    // Thanks & Goodbye
    { k: ['thank','thanks','appreciate','helpful','great'], r: "You're very welcome! We hope to see you at Rashmika Home Stay soon. Feel free to ask anything else — we're happy to help!" },
    { k: ['bye','goodbye','see you','later','take care'], r: "Goodbye! We look forward to welcoming you to Maskeliya. Have a wonderful trip to Adam's Peak — it's an experience you'll never forget!" },
  ];

  function getReply(text) {
    const t = text.toLowerCase();
    for (const entry of kb) {
      if (entry.k.some(kw => new RegExp(kw).test(t))) return entry.r;
    }
    return "I'm not sure about that — please contact us at +94 77 712 3456 or info@rashmikahomestay.lk and we'll be happy to help!";
  }

  function addMsg(text, who) {
    const div = document.createElement('div');
    div.className = 'chat-msg ' + who;
    div.textContent = text;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function typing(cb) {
    const div = document.createElement('div');
    div.className = 'chat-msg bot';
    div.innerHTML = '<span style="opacity:0.5;">typing…</span>';
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
    setTimeout(() => { msgs.removeChild(div); cb(); }, 700);
  }

  function send() {
    const text = input.value.trim();
    if (!text) return;
    addMsg(text, 'user');
    input.value = '';
    typing(() => addMsg(getReply(text), 'bot'));
  }

  sendBtn.addEventListener('click', send);
  input.addEventListener('keydown', e => { if (e.key === 'Enter') send(); });
})();
